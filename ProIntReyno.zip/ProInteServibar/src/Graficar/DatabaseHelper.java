package Graficar;

import java.sql.ResultSet;

public class DatabaseHelper {

	public static ResultSet getChartData() {
		// TODO Auto-generated method stub
		return null;
	}

}

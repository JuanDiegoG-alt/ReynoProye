package Graficar;

import javafx.scene.chart.LineChart;
import javafx.scene.layout.Pane;

public interface Factorychart {
	
	public void crearLineas(Pane container);
	public void crearBarras(Pane container);

}
